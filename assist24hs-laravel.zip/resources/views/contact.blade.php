@extends('template.main')

@section('title' , 'Contato do Site')

@section('content')

<div class="container-fluid contato">
    <div class="bloco-contato">
        <h1>Contato</h1>
        <h2>Whatspp</h2>
        <p>(11)2863-0153</p>
        <h2>E-mail</h2>
        <p>contato@assistenci24hs.srv.br</p>
    </div>
    
</div>

@endsection