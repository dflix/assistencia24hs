@extends('template.main')

@section('title' , "Assistencia 24 Horas")

@section('content')

<div class="container-fluid assistencia">
    <h1>Contrate</h1>
</div>


@endsection