

<?php $__env->startSection('title' , 'Contato do Site'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid contato">
    <div class="bloco-contato">
        <h1>Contato</h1>
        <h2>Whatspp</h2>
        <p>(11)2863-0153</p>
        <h2>E-mail</h2>
        <p>contato@assistenci24hs.srv.br</p>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\assist24hs-laravel\resources\views/contact.blade.php ENDPATH**/ ?>