

<?php $__env->startSection('title' , "Assistencia 24 Horas"); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid assistencia">
    <h1>Contrate</h1>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\assist24hs-laravel\resources\views/hire.blade.php ENDPATH**/ ?>